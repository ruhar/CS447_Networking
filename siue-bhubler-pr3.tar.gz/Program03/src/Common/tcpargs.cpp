#include "tcpargs.hpp"
#include <netinet/in.h>

using namespace std;
using namespace cs447;

tcpargs::tcpargs()
{    
}

tcpargs::~tcpargs()
{
}